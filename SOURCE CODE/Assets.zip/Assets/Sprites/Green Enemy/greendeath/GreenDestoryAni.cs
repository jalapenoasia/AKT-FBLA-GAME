using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenDestoryAni : MonoBehaviour
{
   void DestroyGO(){
       Destroy(gameObject);
   }
}
