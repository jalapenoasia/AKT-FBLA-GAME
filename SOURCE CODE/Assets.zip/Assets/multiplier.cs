using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class multiplier : MonoBehaviour
{
    public bool timesThree;

    void Start()
    {
        timesThree = false;
    }

    // Update is called once per frame
    void Update()
    {
       if(timesThree = true){
           ScoreManager.instance.ChangeScore(Enemy.instance.pointValue *3);

       } else{
           ScoreManager.instance.ChangeScore(Enemy.instance.pointValue);
       }
    }

    void OnTriggerEnter2D(Collider2D other){
        if(other.gameObject.CompareTag("Ship")){
            timesThree = true;
             StartCoroutine(StartPower());
        }
    }

    IEnumerator StartPower(){
        Destroy(gameObject);
        yield return new WaitForSeconds(10); 
        timesThree = false;

    }
}

