using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Timer2 : MonoBehaviour
{
    public GameObject timecounterGO;

void Start(){
     timecounterGO.GetComponent<Timer>().startTimeCounter(); }

     void Update(){
         if(GameControl.health == 0){ timecounterGO.GetComponent<Timer>().stopTimeCounter();

         }
     }

}