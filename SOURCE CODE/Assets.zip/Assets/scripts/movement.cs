using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class movement : MonoBehaviour
{
    public float speed;
    private Rigidbody2D myRigidbody;
    private Vector3 change;

    void Start() {
        myRigidbody = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate() {
        change = Vector3.zero;
        change.x = Input.GetAxisRaw("Horizontal");
        change.y = Input.GetAxisRaw("Vertical");
    {
        MoveCharacter();
    }
    }
    void MoveCharacter() 
    {
        myRigidbody.MovePosition(transform.position + change.normalized * speed * Time.fixedDeltaTime
        );
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.CompareTag("point"))
        {
            Destroy(other.gameObject);
        }
  
    }
}
