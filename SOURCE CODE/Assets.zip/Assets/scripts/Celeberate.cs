using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Celeberate : MonoBehaviour
{
    public GameObject sentence;
    public float startdelay;
    
void Start(){
        if(GameObject.Find("EnemySpawn").GetComponent<EnemyLevelSpawner>().killedenemy == GameObject.Find("EnemySpawn").GetComponent<EnemyLevelSpawner>().maxEnemies){  StartCoroutine(ShowAndHide());}

}

IEnumerator ShowAndHide(){
  sentence.gameObject.SetActive(false);
    yield return new WaitForSeconds(startdelay);
        sentence.gameObject.SetActive(true);

}

}