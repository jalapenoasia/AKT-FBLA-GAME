using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SEnemyNoAdvance : MonoBehaviour
{
    public Enemy[] prefabs;

public int rows = 3;

public int columns = 5;

public float speed = 10.0f;

private Vector3 _direction = Vector2.right;

private void Awake()
{
    for (int col = 0; col < this.columns; col++)
    { 
        float width = 2f * (this.columns -1);
        float height = 2f * (this.rows -1);
        Vector2 centering = new Vector2(-width / 2, - height /2);
        Vector3 colPosition = new Vector3(centering.x, centering.y + (col * 0f), 2f);

        for (int row = 0; row < this.rows; row++)
        {
             Enemy enemy = Instantiate(this.prefabs[col], this.transform);
             Vector3 position = colPosition;
             position.x += col * 2f;
             enemy.transform.localPosition = position;
         }
      }

     }

     private void Update()
     {
         this.transform.position += _direction * speed * Time.deltaTime;

        Vector3 leftEdge = Camera.main.ViewportToWorldPoint(Vector3.zero);
        Vector3 rightEdge = Camera.main.ViewportToWorldPoint(Vector3.right);

         foreach(Transform enemy in this.transform)
         {
             if (!enemy.gameObject.activeInHierarchy){
                 continue;
             }

             if (_direction == Vector3.right && enemy.position.x >= rightEdge.x - 1f) { 
                AdvanceRow();}
                else if (_direction == Vector3.left && enemy.position.x <= leftEdge.x + 1f){
                    AdvanceRow();
                }

             }
     }
      private void AdvanceRow()
        {
            _direction.x *= -1f;

            Vector3 position = this.transform.position;
            position.y -= 0f;
            this.transform.position = position;}
}
