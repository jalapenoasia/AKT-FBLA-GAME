using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooter : MonoBehaviour{

public GameObject EnemyProjectile;
    private float timeBtwShots;
    public float repeatRate;
  

    void Start()
  
    {
      InvokeRepeating("FireEnemyProjectile", 1f, 3f);
    }


    void FireEnemyProjectile()
    {
        GameObject ship = GameObject.FindGameObjectWithTag("Ship");
      

            if(ship != null)
            { 
              
                GameObject bullet =(GameObject)Instantiate(EnemyProjectile);

                bullet.transform.position = transform.position;

                Vector2 direction = ship.transform.position - bullet.transform.position;

                bullet.GetComponent<EnemyProjectile>().SetDirection(direction);
                          }}}
 

