using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenDeath : MonoBehaviour
{
  private Animator _anim;

    void Start()
    {
       
    }

    // Update is called once per frame
  private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player"){
            _anim.SetTrigger("GreenEnemyDeath");
            Destroy(this.gameObject, 5.0f);
        }
        
    }
}

