using UnityEngine;

public class Enemy : MonoBehaviour
{
  public static Enemy instance;
    public SpriteRenderer[] animationSprites;
    private Rigidbody2D rb;
   public float animationTime = 1.0f;
 public AudioSource EnemyDeath;
     public GameObject Death;

   private SpriteRenderer _spriteRenderer;

   private int _animationFrame;
 public int pointValue = 00100;


   private void Awake()
   { 
       _spriteRenderer = GetComponent<SpriteRenderer>();
   }

   private void Start()
   {
       InvokeRepeating(nameof(AnimateSprite), this.animationTime, this.animationTime);
       rb = GameObject.FindGameObjectWithTag("point").GetComponent<Rigidbody2D>();

   }
//animation frames for sprite
   private void AnimateSprite()
   {
       _animationFrame++;

       if (_animationFrame >= this.animationSprites.Length)  {
           _animationFrame = 0; } 

         _spriteRenderer = this.animationSprites[_animationFrame];
   }

     private void OnTriggerEnter2D(Collider2D other)
    {

    // if the enemy hits the ship then score will increase, killed counter for enemies will increase, and enemy death explosion will be invoked.     
        if (other.gameObject.CompareTag("Player"))
        { 
            ScoreManager.instance.ChangeScore(pointValue);
            GameObject.Find("EnemySpawn").GetComponent<EnemyLevelSpawner>().killedenemy += 1; 
            PlayExplosion();}

       // if the enemy hits the ship then players health be subtracted by one, killed counter for enemies will increase, and enemy death explosion will be invoked.     
        if(other.gameObject.CompareTag("Ship"))
        {
            GameControl.health -= 1;
            GameObject.Find("EnemySpawn").GetComponent<EnemyLevelSpawner>().killedenemy += 1;  
            PlayExplosion();}
        
        }
        //playing enemy death animation
    void PlayExplosion(){

      GameObject death = (GameObject) Instantiate (Death);

      death.transform.position = transform.position;
    }
    
    }


