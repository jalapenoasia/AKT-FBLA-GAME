using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Highscore : MonoBehaviour
{
    public static Highscore instance;
    public TextMeshProUGUI text;
    public static int highscore;

    void Start()
    {
        if(instance == null)
        {
            instance = this;
        }
    }

    public void ChangeScore(int score)
   {
       highscore += score;
       text.text = "highscore " + highscore.ToString();
   }
}

