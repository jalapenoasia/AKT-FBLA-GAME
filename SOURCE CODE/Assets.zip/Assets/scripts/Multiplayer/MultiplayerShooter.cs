using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultiplayerShooter : MonoBehaviour
{public GameObject EnemyProjectile;
    private float timeBtwShots;
    public float repeatRate;

    void Start()
  
    {
      InvokeRepeating("FireEnemyProjectile", 1f, 3f);
    }


    void FireEnemyProjectile()
    {
        GameObject player1 = GameObject.Find("Ship");
        GameObject player2 = GameObject.Find("Ship2");

            if(player1 != null)
            { 
                GameObject bullet =(GameObject)Instantiate(EnemyProjectile);

                bullet.transform.position = transform.position;

                Vector2 direction = player1.transform.position - bullet.transform.position;

                bullet.GetComponent<EnemyProjectile>().SetDirection(direction);}
                 if(player2 != null)
            { 
                GameObject bullet =(GameObject)Instantiate(EnemyProjectile);

                bullet.transform.position = transform.position;

                Vector2 direction = player2.transform.position - bullet.transform.position;

                bullet.GetComponent<EnemyProjectile>().SetDirection(direction);}}}
