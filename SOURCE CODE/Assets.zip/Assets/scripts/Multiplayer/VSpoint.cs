using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VSpoint : MonoBehaviour
{
    public int pointValue = 00100;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player1"))
        { 
            ScoreManager.instance.ChangeScore(pointValue);
        }
        if (other.gameObject.CompareTag("Player2"))
        { 
            ScoreManager.instance.ChangeScore(pointValue);
        }
    }
}
