using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class VSScoreManager : MonoBehaviour
{   
    public static VSScoreManager instance;
    public TextMeshProUGUI scoretext, scoretext2;
    
    public int score;
    public int score2;

   void Start(){
   if(instance == null)
        {
            instance = this;

    }}

   public void ChangeScore(int pointValue)
   {
       score += pointValue;
       scoretext.text = "P1 score " + score.ToString();   
   } 
    public void ChangeScore2(int pointValue)
   {
       score2 += pointValue;
       scoretext2.text = "P2 score " + score2.ToString();
}}

