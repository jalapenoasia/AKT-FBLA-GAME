using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossShooter1 : MonoBehaviour{

public GameObject BossProjectile;
    private float timeBtwShots;
  

    void Start()
  
    {
      InvokeRepeating("FireBossProjectile", 1f, 0.15f);

    }
    void Update(){

    }


    void FireBossProjectile()
    {
        GameObject ship = GameObject.Find ("Ship");

            if(ship != null){
            GameObject bullet =(GameObject)Instantiate(BossProjectile);

                bullet.transform.position = transform.position;

                Vector2 direction = ship.transform.position - bullet.transform.position;

                bullet.GetComponent<BossProjectile>().SetDirection(direction);}}}
