using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss3Enemy : MonoBehaviour
{
    public SpriteRenderer[] animationSprites;
    private Rigidbody2D rb;
   public float animationTime = 1.0f;
   public AudioSource EnemyDeath;
     public GameObject Death;
 

   private SpriteRenderer _spriteRenderer;

   private int _animationFrame;
 public int pointValue = 00100;


   private void Awake()
   { 
       _spriteRenderer = GetComponent<SpriteRenderer>();
   }

   private void Start()
   {
       InvokeRepeating(nameof(AnimateSprite), this.animationTime, this.animationTime);
       rb = GameObject.FindGameObjectWithTag("point").GetComponent<Rigidbody2D>();

   }

   private void AnimateSprite()
   {
       _animationFrame++;

       if (_animationFrame >= this.animationSprites.Length)  {
           _animationFrame = 0; } 

         _spriteRenderer = this.animationSprites[_animationFrame];
   }

     private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        { 
            ScoreManager.instance.ChangeScore(pointValue);
            EnemyHealth3.e3health -= 1;
         }
        if(other.gameObject.CompareTag("Ship"))
        {
            GameControl.health -= 1;

    }
    if( EnemyHealth3.e3health == 0){
        Destroy(gameObject); 
        PlayExplosion();}
    }
        
    
    
    void PlayExplosion(){

      GameObject death = (GameObject) Instantiate (Death);

      death.transform.position = transform.position;
    }}