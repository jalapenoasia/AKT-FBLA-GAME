using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public GameObject enemyhealth0, enemyhealth1, enemyhealth2, enemyhealth3, enemyhealth4, next, fireworks;
    public static int ehealth;
    // Start is called before the first frame update
    void Start (){
       ehealth = 5;
       enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
        next.gameObject.SetActive (false);
        fireworks.gameObject.SetActive (false);
        

   }
   
   void Update () {
       if (ehealth == 5)
       ehealth = 5;

       switch (ehealth){
           case 5:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
          next.gameObject.SetActive (false);
          fireworks.gameObject.SetActive (false);
          
       break;

       case 4:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (false);
          next.gameObject.SetActive (false);
           fireworks.gameObject.SetActive (false);
          
       break;

       case 3:
      enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(false);
        enemyhealth4.gameObject.SetActive (false);
          next.gameObject.SetActive (false);
         fireworks.gameObject.SetActive (false);
       break;

       case 2:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (false);
        enemyhealth3.gameObject.SetActive(false);
        enemyhealth4.gameObject.SetActive (false);
          next.gameObject.SetActive (false);
           fireworks.gameObject.SetActive (false);
          


       break;

       case 1:
       enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (false);
       enemyhealth2.gameObject.SetActive (false);
        enemyhealth3.gameObject.SetActive(false);
        enemyhealth4.gameObject.SetActive (false);
          next.gameObject.SetActive (false);
           fireworks.gameObject.SetActive (false);

        break;

    case 0:
    enemyhealth0.gameObject.SetActive (false);
       enemyhealth1.gameObject.SetActive (false);
       enemyhealth2.gameObject.SetActive (false);
        enemyhealth3.gameObject.SetActive(false);
        enemyhealth4.gameObject.SetActive (false);
          next.gameObject.SetActive (true);
           fireworks.gameObject.SetActive (true);

        break;
          
          


    

       

       
           

   }
   }}
