using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth3 : MonoBehaviour
{
    public GameObject enemyhealth0, enemyhealth1, enemyhealth2, enemyhealth3, enemyhealth4, enemyhealth5, enemyhealth6, enemyhealth7, enemyhealth8, enemyhealth9, enemyhealth10, enemyhealth11, enemyhealth12, enemyhealth13, enemyhealth14, next;
    public static int e3health;

    // Start is called before the first frame update
    void Start (){
       e3health = 15;
       enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
        enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(true);
        enemyhealth9.gameObject.SetActive(true);
        enemyhealth10.gameObject.SetActive(true);
        enemyhealth11.gameObject.SetActive(true);
        enemyhealth12.gameObject.SetActive(true);
        enemyhealth13.gameObject.SetActive(true);
        enemyhealth14.gameObject.SetActive(true);
        next.gameObject.SetActive (false);
        

   }
   
   void Update () {
       if (e3health == 15)
       e3health = 15;

       switch (e3health){

           case 15:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(true);
        enemyhealth9.gameObject.SetActive(true);
        enemyhealth10.gameObject.SetActive(true);
        enemyhealth11.gameObject.SetActive(true);
        enemyhealth12.gameObject.SetActive(true);
        enemyhealth13.gameObject.SetActive(true);
        enemyhealth14.gameObject.SetActive(true);
          next.gameObject.SetActive (false);
          
       break;

           case 14:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(true);
        enemyhealth9.gameObject.SetActive(true);
        enemyhealth10.gameObject.SetActive(true);
        enemyhealth11.gameObject.SetActive(true);
        enemyhealth12.gameObject.SetActive(true);
        enemyhealth13.gameObject.SetActive(true);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;

        case 13:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(true);
        enemyhealth9.gameObject.SetActive(true);
        enemyhealth10.gameObject.SetActive(true);
        enemyhealth11.gameObject.SetActive(true);
        enemyhealth12.gameObject.SetActive(true);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;

           case 12:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(true);
        enemyhealth9.gameObject.SetActive(true);
        enemyhealth10.gameObject.SetActive(true);
        enemyhealth11.gameObject.SetActive(true);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;

 case 11:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(true);
        enemyhealth9.gameObject.SetActive(true);
        enemyhealth10.gameObject.SetActive(true);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;


             case 10:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(true);
        enemyhealth9.gameObject.SetActive(true);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;

            case 9:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(true);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;

           case 8:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(true);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;
           case 7:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(true);
        enemyhealth7.gameObject.SetActive(false);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;
           case 6:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(true);
        enemyhealth6.gameObject.SetActive(false);
        enemyhealth7.gameObject.SetActive(false);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;
           case 5:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (true);
         enemyhealth5.gameObject.SetActive(false);
        enemyhealth6.gameObject.SetActive(false);
        enemyhealth7.gameObject.SetActive(false);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;

       case 4:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(true);
        enemyhealth4.gameObject.SetActive (false);
        enemyhealth5.gameObject.SetActive(false);
        enemyhealth6.gameObject.SetActive(false);
        enemyhealth7.gameObject.SetActive(false);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;

       case 3:
      enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (true);
        enemyhealth3.gameObject.SetActive(false);
        enemyhealth4.gameObject.SetActive (false);
        enemyhealth5.gameObject.SetActive(false);
        enemyhealth6.gameObject.SetActive(false);
        enemyhealth7.gameObject.SetActive(false);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          
       break;

       case 2:
        enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (true);
       enemyhealth2.gameObject.SetActive (false);
        enemyhealth3.gameObject.SetActive(false);
        enemyhealth4.gameObject.SetActive (false);
        enemyhealth5.gameObject.SetActive(false);
        enemyhealth6.gameObject.SetActive(false);
        enemyhealth7.gameObject.SetActive(false);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);
          


       break;

       case 1:
       enemyhealth0.gameObject.SetActive (true);
       enemyhealth1.gameObject.SetActive (false);
       enemyhealth2.gameObject.SetActive (false);
        enemyhealth3.gameObject.SetActive(false);
        enemyhealth4.gameObject.SetActive (false);
        enemyhealth5.gameObject.SetActive(false);
        enemyhealth6.gameObject.SetActive(false);
        enemyhealth7.gameObject.SetActive(false);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (false);

        break;

    case 0:
    enemyhealth0.gameObject.SetActive (false);
       enemyhealth1.gameObject.SetActive (false);
       enemyhealth2.gameObject.SetActive (false);
        enemyhealth3.gameObject.SetActive(false);
        enemyhealth4.gameObject.SetActive (false);
        enemyhealth5.gameObject.SetActive(false);
        enemyhealth6.gameObject.SetActive(false);
        enemyhealth7.gameObject.SetActive(false);
        enemyhealth8.gameObject.SetActive(false);
        enemyhealth9.gameObject.SetActive(false);
        enemyhealth10.gameObject.SetActive(false);
        enemyhealth11.gameObject.SetActive(false);
        enemyhealth12.gameObject.SetActive(false);
        enemyhealth13.gameObject.SetActive(false);
        enemyhealth14.gameObject.SetActive(false);
          next.gameObject.SetActive (true);

        break;
          
          


    

       

       
           

   }
   }}
