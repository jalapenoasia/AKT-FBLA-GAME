using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipMovement : MonoBehaviour
{
    public projectile shooterPreFab;
    public float speed;
    private Rigidbody2D myRigidbody;
    private Vector3 change;
    private bool _shooterActive;
    private Vector2 velocity;
  public AudioSource PlayerShot, Damage;
  public GameObject destroyed;


    void Start() {
        myRigidbody = GetComponent<Rigidbody2D>();
    }

  void FixedUpdate() {
        change = Vector3.zero;
        change.x = Input.GetAxisRaw("Horizontal"); 
     

    {
        MoveCharacter();
    }
    }
    void MoveCharacter() 
    {
        myRigidbody.MovePosition(transform.position + change.normalized * speed * Time.fixedDeltaTime
        );

         if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)) {
        Shoot();
    }
    }

    private void Shoot(){
        
        if (!_shooterActive){
       projectile Projectile = Instantiate(this.shooterPreFab, this.transform.position, Quaternion.identity);
       Projectile.destroyed +=  ShooterDestroyed;
        _shooterActive = true; }
         PlayerShot.Play();
    }

    private void ShooterDestroyed(){
        _shooterActive = false;
    }
   private void OnTriggerEnter2D (Collider2D other)
    {

        if(other.gameObject.CompareTag("point"))
        {
            Destroy(other.gameObject);} 
            
            if(PowerController.plus2 >= 1){
                PowerController.plus2 -= PowerController.plus2;
                Damage.Play();

             }
        if(other.gameObject.CompareTag("EnemyProjectile"))
        {
            Destroy(other.gameObject);
            GameControl.health -=1; }
           if(PowerController.plus2 >= 1){
                PowerController.plus2 -= PowerController.plus2;
                  Damage.Play();
             }
        if(other.gameObject.CompareTag("powerup")){
            Destroy(other.gameObject);
            PowerController.plus2 +=1;}}}