using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ship2 : MonoBehaviour
{
    public projectile shooterPreFab;
    public float speed;
    private Rigidbody2D myRigidbody;
    private Vector3 change;
    private bool _shooterActive;
    private Vector2 velocity;
    private float movementx;


    void Start() {
        myRigidbody = GetComponent<Rigidbody2D>();
    }

  void FixedUpdate() {
        change = Vector3.zero;
        change.x = Input.GetAxisRaw("Horizontal"); 
     

    {
        MoveCharacter();
    }
    }
    void MoveCharacter() 
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            movementx = -1;
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            movementx = 1;
        }
         if (Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.A))
        {
            movementx = 0;
        }
        myRigidbody.velocity = new Vector2(movementx * speed * Time.fixedDeltaTime, 0);


         if (Input.GetKeyDown(KeyCode.W) || Input.GetMouseButtonDown(0)) {
        Shoot();
    }
    }

    private void Shoot(){
        if (!_shooterActive){
       projectile Projectile = Instantiate(this.shooterPreFab, this.transform.position, Quaternion.identity);
       Projectile.destroyed +=  ShooterDestroyed;
        _shooterActive = true; }
    }

    private void ShooterDestroyed(){
        _shooterActive = false;
    }
   private void OnTriggerEnter2D (Collider2D other)
    {

        if(other.gameObject.CompareTag("point"))
        {
            Destroy(other.gameObject);} 
            
            if(PowerController.plus2 >= 1){
                PowerController.plus2 -= PowerController.plus2;
             }
        if(other.gameObject.CompareTag("EnemyProjectile"))
        {
            Destroy(other.gameObject);
            GameControl.health -=1; }
           if(PowerController.plus2 >= 1){
                PowerController.plus2 -= PowerController.plus2;
             }
        if(other.gameObject.CompareTag("powerup")){
            Destroy(other.gameObject);
            PowerController.plus2 +=1;}}
}