using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ship2 : MonoBehaviour
{
    public projectile shooterPreFab;
    public float speed;
    private Rigidbody2D myRigidbody;
    private Vector3 change;
   public bool _2shooterActive;
    private Vector2 velocity;
    private float movementx;
     public float delay;


    void Start() {
        myRigidbody = GetComponent<Rigidbody2D>();
    }

  void FixedUpdate() {
        change = Vector3.zero;
        change.x = Input.GetAxisRaw("Horizontal"); 
     

    {
        MoveCharacter();
    }
    }
    void MoveCharacter() 
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            movementx = -1;
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            movementx = 1;
        }
         if (Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.A))
        {
            movementx = 0;
        }
        myRigidbody.velocity = new Vector2(movementx * speed * Time.fixedDeltaTime, 0);


         if (Input.GetKeyDown(KeyCode.W)){
    Check();
    }
    }
    private void Check(){
        if (!_2shooterActive){StartCoroutine(Shoot());}
    }

    public IEnumerator Shoot(){ 
        projectile Projectile = Instantiate(this.shooterPreFab, this.transform.position, Quaternion.identity); //instatiate shot
           _2shooterActive = true; 
         yield return new WaitForSeconds(delay); 
        _2shooterActive = false;
        
    }


   private void OnTriggerEnter2D (Collider2D other)
    {

        if(other.gameObject.CompareTag("point"))
        {
            Destroy(other.gameObject);} 
           
        if(other.gameObject.CompareTag("EnemyProjectile"))
        {
            Destroy(other.gameObject);
            GameControl.health -=1; }
          }
}