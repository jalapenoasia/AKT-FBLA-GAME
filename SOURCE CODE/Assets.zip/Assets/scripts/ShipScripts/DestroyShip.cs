using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyShip : MonoBehaviour
{
public GameObject ship, ship2;

void Start(){
    ship.gameObject.SetActive(true);
    ship2.gameObject.SetActive(true);
}

void Update(){
    if(GameControl.health == 0){ 
        ship.gameObject.SetActive(false);
        ship2.gameObject.SetActive(false);
     }
}}
