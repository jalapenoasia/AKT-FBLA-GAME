using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class projectile : MonoBehaviour
{
   public Vector3 direction;
   public System.Action destroyed;
    private Animator _anim;


   public float speed;

   private void Start(){
         _anim = GetComponent<Animator>();
   }

   private void Update()
   {
       this.transform.position += this.direction * this.speed * this.speed * Time.deltaTime;
   }

   private void OnTriggerEnter2D(Collider2D other)
   {

       this.destroyed.Invoke();
       Destroy(this.gameObject);
  if(other.gameObject.CompareTag("point"))
        {
            Destroy(other.gameObject);
            
            }


        if(other.gameObject.CompareTag("EnemyProjectile"))
        {
            Destroy(other.gameObject); 
             }


   }
}
