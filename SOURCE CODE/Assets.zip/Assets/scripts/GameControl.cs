using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameControl : MonoBehaviour
{
   public GameObject health0, health1, health2, gameOver,Reset, nextLevel, shipdie, shipdie2, shipdie3, shipdie4;
   public static int health; 

   void Start(){
       health = 3;
        Time.timeScale = 1f;
       health0.gameObject.SetActive (true);
       health1.gameObject.SetActive (true);
       health2.gameObject.SetActive (true);
        Reset.gameObject.SetActive(false);
           gameOver.gameObject.SetActive (false);
           shipdie.gameObject.SetActive (false);
            shipdie2.gameObject.SetActive (false);
             shipdie3.gameObject.SetActive (false);
              shipdie4.gameObject.SetActive (false);
          
          
        

   }
   
   void Update () {
       if (health == 3)
       health = 3;

       switch (health){
           case 3:
        health0.gameObject.SetActive (true);
       health1.gameObject.SetActive (true);
       health2.gameObject.SetActive (true);
        Reset.gameObject.SetActive(false);
           gameOver.gameObject.SetActive (false);
            shipdie.gameObject.SetActive (false);
            shipdie2.gameObject.SetActive (false);
             shipdie3.gameObject.SetActive (false);
              shipdie4.gameObject.SetActive (false);
          
        
       break;

       case 2:
        health0.gameObject.SetActive (true);
       health1.gameObject.SetActive (true);
       health2.gameObject.SetActive (false);
        Reset.gameObject.SetActive(false);
           gameOver.gameObject.SetActive (false);
            shipdie.gameObject.SetActive (false);
            shipdie2.gameObject.SetActive (false);
             shipdie3.gameObject.SetActive (false);
              shipdie4.gameObject.SetActive (false);
          
       break;

       case 1: 
        health0.gameObject.SetActive (true);
       health1.gameObject.SetActive (false);
       health2.gameObject.SetActive (false);
        Reset.gameObject.SetActive(false);
           gameOver.gameObject.SetActive (false);
            shipdie.gameObject.SetActive (false);
            shipdie2.gameObject.SetActive (false);
             shipdie3.gameObject.SetActive (false);
              shipdie4.gameObject.SetActive (false);
          
       break;

       case 0:    Time.timeScale = 0f;
       ScoreManager.score = 0;
        health0.gameObject.SetActive (false);
       health1.gameObject.SetActive (false);
       health2.gameObject.SetActive (false);
       gameOver.gameObject.SetActive (true);
       Reset.gameObject.SetActive(true);
       shipdie.gameObject.SetActive (true);
            shipdie2.gameObject.SetActive (true);
             shipdie3.gameObject.SetActive (true);
              shipdie4.gameObject.SetActive (true);
        


       break;
    

       

       
           

   }
   }}
