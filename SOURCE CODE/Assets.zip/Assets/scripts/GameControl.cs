using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameControl : MonoBehaviour
{
   public GameObject health0, health1, health2, gameOver,Reset, nextLevel;
   public static int health; 

   void Start (){
       health = 3;
       health0.gameObject.SetActive (true);
       health1.gameObject.SetActive (true);
       health2.gameObject.SetActive (true);
        Reset.gameObject.SetActive(false);
           gameOver.gameObject.SetActive (false);
           Time.timeScale = 1f;
          
        

   }
   
   void Update () {
       if (health == 3)
       health = 3;

       switch (health){
           case 3:
        health0.gameObject.SetActive (true);
       health1.gameObject.SetActive (true);
       health2.gameObject.SetActive (true);
        Reset.gameObject.SetActive(false);
           gameOver.gameObject.SetActive (false);
        
       break;

       case 2:
        health0.gameObject.SetActive (true);
       health1.gameObject.SetActive (true);
       health2.gameObject.SetActive (false);
        Reset.gameObject.SetActive(false);
           gameOver.gameObject.SetActive (false);
       break;

       case 1:
        health0.gameObject.SetActive (true);
       health1.gameObject.SetActive (false);
       health2.gameObject.SetActive (false);
        Reset.gameObject.SetActive(false);
           gameOver.gameObject.SetActive (false);
       break;

       case 0:
        health0.gameObject.SetActive (false);
       health1.gameObject.SetActive (false);
       health2.gameObject.SetActive (false);
       gameOver.gameObject.SetActive (true);
       Reset.gameObject.SetActive(true);
       Time.timeScale = 0f;
        


       break;
    

       

       
           

   }
   }}
