using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntroButton : MonoBehaviour
{
    public GameObject button;
    public float startdelay;
    
void Start(){
    StartCoroutine(ShowAndHide());
}

IEnumerator ShowAndHide(){
      button.gameObject.SetActive(false);
    yield return new WaitForSeconds(startdelay);
    button.gameObject.SetActive(true);}}

