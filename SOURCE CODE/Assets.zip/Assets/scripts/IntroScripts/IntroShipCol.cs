using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntroShipCol : MonoBehaviour
{
    
    public float speed;
    private Rigidbody2D myRigidbody;
    private Vector3 change;
    private bool _shooterActive;
    private Vector2 velocity;
  public AudioSource PlayerShot, Damage;


    void Start() {
        myRigidbody = GetComponent<Rigidbody2D>();
    }
     

   private void OnTriggerEnter2D (Collider2D other)
    {

        if(other.gameObject.CompareTag("point"))
        {
            Destroy(other.gameObject);} 
            
            if(PowerController.plus2 >= 1){
                PowerController.plus2 -= PowerController.plus2;
                Damage.Play();

             }
        if(other.gameObject.CompareTag("EnemyProjectile"))
        {
            Destroy(other.gameObject);
            GameControl.health -=1; }
           if(PowerController.plus2 >= 1){
                PowerController.plus2 -= PowerController.plus2;
                  Damage.Play();
             }
        if(other.gameObject.CompareTag("powerup")){
            Destroy(other.gameObject);
            PowerController.plus2 +=1;}}
}
