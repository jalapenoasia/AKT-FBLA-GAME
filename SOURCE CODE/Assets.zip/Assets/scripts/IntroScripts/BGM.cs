using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGM : MonoBehaviour
{public AudioSource SFX;
    public float startdelay;
   
    
void Start(){
    StartCoroutine(ShowAndHide());
}

IEnumerator ShowAndHide(){

    yield return new WaitForSeconds(startdelay);
       SFX.Play();
    
 ;
  
}

}
