using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TSoundManager : MonoBehaviour
{
    public AudioSource SFX;
    public float startdelay;
      public float stopdelay;
    
void Start(){
    StartCoroutine(ShowAndHide());
}

IEnumerator ShowAndHide(){

    yield return new WaitForSeconds(startdelay);
       SFX.Play();
       yield return new WaitForSeconds(stopdelay);
    SFX.Stop();
 ;
  
}

}