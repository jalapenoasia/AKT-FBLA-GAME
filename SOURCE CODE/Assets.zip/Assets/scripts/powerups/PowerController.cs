using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerController : MonoBehaviour
{public GameObject Plus2, TPlus2;
   public static int health; 
   public static int plus2;

   void Start (){
       plus2 = 0;
           Plus2.gameObject.SetActive(false);
           TPlus2.gameObject.SetActive(false);}
   
   void Update () {
       if (plus2 >= 1)
       plus2 = 1;

       switch(plus2){

       case 1: 
           Plus2.gameObject.SetActive(true);
           TPlus2.gameObject.SetActive(true);

           break;

        case 0:
        Plus2.gameObject.SetActive(false);
           TPlus2.gameObject.SetActive(false);
           break; }

   }
   }

