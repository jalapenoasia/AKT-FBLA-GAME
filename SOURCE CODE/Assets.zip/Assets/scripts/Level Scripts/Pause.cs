using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pause : MonoBehaviour
{
   public GameObject pausemenu;
public bool isPaused;


    void Start()

    {
    pausemenu.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Tab)){
            if(isPaused){
                ResumeGame();
            }

            else{
                PauseGame();
            }

        }
    }
    public void PauseGame(){
pausemenu.gameObject.SetActive(true);
Time.timeScale = 0f;
isPaused = true;
    }

    public void ResumeGame(){
        pausemenu.gameObject.SetActive(false);
        Time.timeScale = 1f;
        isPaused = false;
        
    }
}
