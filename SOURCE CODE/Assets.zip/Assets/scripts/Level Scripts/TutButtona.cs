using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutButtona : MonoBehaviour
{
    public GameObject move, shoot;
    // Start is called before the first frame update
    void Start()
    {
        move.gameObject.SetActive(true);
        shoot.gameObject.SetActive(true);
    }

    // Update is called once per frame
    public void moveclicked()
    {
        move.gameObject.SetActive(false);
    }

    public void shootclicked(){
        shoot.gameObject.SetActive(false);
    }
}
