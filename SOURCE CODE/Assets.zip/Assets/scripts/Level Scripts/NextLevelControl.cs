using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextLevelControl : MonoBehaviour
{public GameObject next;


void Start()
    {
   next.gameObject.SetActive(false);
    }


   void Update(){
       if(GameObject.Find("EnemySpawn").GetComponent<EnemyLevelSpawner>().killedenemy == GameObject.Find("EnemySpawn").GetComponent<EnemyLevelSpawner>().maxEnemies){

      next.gameObject.SetActive(true); }}}
