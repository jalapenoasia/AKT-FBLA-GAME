using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReturnControl : MonoBehaviour
{public GameObject menu;

void Start()
    {
   menu.gameObject.SetActive(false);

    }


   void Update(){
       if(GameObject.Find("EnemySpawn").GetComponent<EnemyLevelSpawner>().killedenemy == GameObject.Find("EnemySpawn").GetComponent<EnemyLevelSpawner>().maxEnemies){

      menu.gameObject.SetActive(true); }
   }}