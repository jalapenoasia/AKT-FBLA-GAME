using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ButSkin : MonoBehaviour
{
    public GameObject skinmenu, returns, quits, skins;

void Awake()

    {
    skinmenu.gameObject.SetActive(false);
    }

    public void SkinMenu(){
skinmenu.gameObject.SetActive(true);
returns.gameObject.SetActive(false);
quits.gameObject.SetActive(false);
skins.gameObject.SetActive(false);
    }

    public void SelectSkin(){
       skinmenu.gameObject.SetActive(false);
       returns.gameObject.SetActive(true);
quits.gameObject.SetActive(true);
skins.gameObject.SetActive(true);
    }}
