using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelUp : MonoBehaviour
{
    public void PlayGame(){ 
            int currentLevel = SceneManager.GetActiveScene().buildIndex;
        
  if(currentLevel >= PlayerPrefs.GetInt("levelAt")){
      PlayerPrefs.SetInt("levelAt", currentLevel + 1);
  }
    }

}
