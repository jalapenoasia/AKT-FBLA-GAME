using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;


public class Scoreboard : MonoBehaviour
{
    [SerializeField] private int maxScoreboardEntries = 5;
    [SerializeField] private Transform highscoresHolderTransform = null;
    [SerializeField] private GameObject scoreboardEntryObject = null;

    [Header("Test")]
    [SerializeField] EntryData testEntryData = new EntryData();

    private string SavePath => $"{Application.persistentDataPath}/highscores.json";


private void Start()
{
    SaveData savedScores = GetSavedScores();

    SaveScores(savedScores);

    UpdateUI(savedScores);

}
[ContextMenu("Add Test Entry")]
public void AddTestEntry()
{
    AddEntry(testEntryData);
}
public void AddEntry(EntryData entryData)
{
    SaveData savedScores = GetSavedScores();

    bool scoreAdded = false;
    for (int i = 0; i <savedScores.highscores.Count; i++){
        if(entryData.entryScore > savedScores.highscores[i].entryScore)
        {
            savedScores.highscores.Insert(i, entryData);
            scoreAdded = true;
            break;
        }
    }
    if(!scoreAdded && savedScores.highscores.Count < maxScoreboardEntries) 
    {
        savedScores.highscores.Add(entryData);
    }

     if(savedScores.highscores.Count > maxScoreboardEntries) 
     {
         savedScores.highscores.RemoveRange(maxScoreboardEntries, savedScores.highscores.Count - maxScoreboardEntries);
     }

     UpdateUI(savedScores);

     SaveScores(savedScores);
}

private void UpdateUI(SaveData savedScores)
{
    foreach(Transform child in highscoresHolderTransform)
    {
        Destroy(child.gameObject);
    }

    foreach(EntryData highscore in savedScores.highscores){
       Instantiate(scoreboardEntryObject, highscoresHolderTransform).GetComponent<EntryUI>().Initialize(highscore);
    }
}

private SaveData GetSavedScores()
{
    // if file doesnt exist, dispose of it
    if(!File.Exists(SavePath))
    {
        File.Create(SavePath).Dispose();
        return new SaveData();
    }
    using(StreamReader stream = new StreamReader(SavePath))
    {
        string json = stream.ReadToEnd();

        return JsonUtility.FromJson<SaveData>(json);
    }
}

private void SaveScores(SaveData saveData)
{
    using(StreamWriter stream = new StreamWriter(SavePath))
    {
        string json = JsonUtility.ToJson(saveData, true);
        stream.Write(json);
    }
}
}

