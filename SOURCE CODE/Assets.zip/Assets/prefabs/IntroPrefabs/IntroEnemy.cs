using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntroEnemy : MonoBehaviour
{

      public AudioSource EnemyShot;
      public bool alreadyPlayed = false;
    
    void Awake()
    {
             
             if(!alreadyPlayed){EnemyShot.Play();
             alreadyPlayed = true;}

    }}

  