using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;



public class EntryUI : MonoBehaviour
{
   [SerializeField] private TextMeshProUGUI entryNameText = null;
   [SerializeField] private TextMeshProUGUI entryScoreText = null;

   public void Initialize(EntryData entryData)
   {
    entryNameText.text = entryData.entryName;  
    entryScoreText.text = entryData.entryScore.ToString(); 
   }
}
