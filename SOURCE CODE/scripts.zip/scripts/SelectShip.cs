using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SelectShip : MonoBehaviour
{
   public AnimatorOverrideController blue;
   public AnimatorOverrideController red;
   public AnimatorOverrideController purple;
   public AnimatorOverrideController green;

public void Blue()
{
GetComponent<Animator>().runtimeAnimatorController = blue as RuntimeAnimatorController;
}

public void Red()
{
GetComponent<Animator>().runtimeAnimatorController = red as RuntimeAnimatorController;
}

public void Default()
{
GetComponent<Animator>().runtimeAnimatorController = purple as RuntimeAnimatorController;
}

public void Green()
{
GetComponent<Animator>().runtimeAnimatorController = green as RuntimeAnimatorController;
}}