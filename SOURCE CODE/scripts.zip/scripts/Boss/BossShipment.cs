using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossShipment : MonoBehaviour
{
    public ShipBossProjectile shooterPreFab;
    public float speed;
    private Rigidbody2D myRigidbody;
    private Vector3 change;
    private bool _shooterActive;
    private Vector2 velocity;
    public float delay;


    void Start() {
        myRigidbody = GetComponent<Rigidbody2D>();
    }

  void FixedUpdate() {
        change = Vector3.zero;
        change.x = Input.GetAxisRaw("Horizontal"); 
     

    {
        MoveCharacter();
    }
    }
    void MoveCharacter() 
    {
        myRigidbody.MovePosition(transform.position + change.normalized * speed * Time.fixedDeltaTime
        );

         if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)) {
        Check();
    }
    }
    private void Check(){
        if (!_shooterActive){StartCoroutine(Shoot());}
    }

    public IEnumerator Shoot(){ 
        ShipBossProjectile Projectile = Instantiate(this.shooterPreFab, this.transform.position, Quaternion.identity); //instatiate shot
           _shooterActive = true; 
         yield return new WaitForSeconds(delay); 
        _shooterActive = false;
    }
   private void OnTriggerEnter2D (Collider2D other)
    {

        if(other.gameObject.CompareTag("EnemyProjectile"))
        {
            Destroy(other.gameObject);
            GameControl.health -=1; }
        if(other.gameObject.CompareTag("powerup")){
            Destroy(other.gameObject);
            PowerController.plus2 +=1;}}
}