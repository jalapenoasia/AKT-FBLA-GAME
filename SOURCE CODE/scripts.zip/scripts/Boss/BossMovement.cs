using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossMovement : MonoBehaviour
{
    public float speed;
    public float stoppingDistance;
    public float retreatDistance;

    private Transform ship;

    void Start()
    {
        ship = GameObject.FindGameObjectWithTag("Ship").transform;
    }

    // Update is called once per frame
    void Update()
    {
        if(Vector2.Distance(transform.position, ship.position) > stoppingDistance){
            transform.position = Vector2.MoveTowards(transform.position, ship.position, speed * Time.deltaTime);

        } else if(Vector2.Distance(transform.position, ship.position) < stoppingDistance && Vector2.Distance(transform.position, ship.position) > retreatDistance){
            transform.position = this.transform.position;

        } else if (Vector2.Distance(transform.position, ship.position)< retreatDistance){
            transform.position = Vector2.MoveTowards(transform.position, ship.position, -speed * Time.deltaTime);
        }
    }
}
