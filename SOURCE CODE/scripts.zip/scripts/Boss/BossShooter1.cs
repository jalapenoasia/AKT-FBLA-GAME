using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossShooter1 : MonoBehaviour{

public GameObject BossProjectile;
    private float timeBtwShots;
        public float repeatRate;
  

    void Start()
  
    {
      InvokeRepeating("FireBossProjectile", 1f, 0.15f);
    }
    void FireBossProjectile()
    {
        GameObject ship = GameObject.FindGameObjectWithTag ("Ship");

            if(ship != null){
            GameObject bullet =(GameObject)Instantiate(BossProjectile);

                bullet.transform.position = transform.position;

                Vector2 direction = ship.transform.position - bullet.transform.position;

                bullet.GetComponent<BossProjectile>().SetDirection(direction);}}}
