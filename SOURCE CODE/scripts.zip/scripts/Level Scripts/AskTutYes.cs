using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AskTutYes : MonoBehaviour
{
      public void PlayGame()
    {
        SceneManager.LoadScene(24);
    }
}
