using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Timer : MonoBehaviour
{
    TextMeshProUGUI timeUI;
    public float startTime;
    public float ellapsedTime;
    bool startCounter;

    int minutes;
    int seconds;
    // Start is called before the first frame update
    void Start()
    {
        startCounter = true;

        timeUI = GetComponent<TextMeshProUGUI>();
    }
    public void startTimeCounter(){
        startTime = Time.time;
        startCounter = true;
    }

    public void stopTimeCounter(){

        startCounter = false;
    }
    // Update is called once per frame
    void Update()
    {
        if(startCounter){
            ellapsedTime = Time.time - startTime;
            minutes = (int)ellapsedTime / 60;
            seconds = (int)ellapsedTime % 60;
           timeUI.text = string.Format("{0:00}:{1:00}", minutes,seconds);
        }
    }
}
