using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipMovement : MonoBehaviour
{
    public projectile shooterPreFab;
    public float speed;
    private Rigidbody2D myRigidbody;
    private Vector3 change;
    private bool _shooterActive;
    private Vector2 velocity;
  public AudioSource PlayerShot, Damage;
  public GameObject destroyed;
  public float delay;
  public bool timesThree = false;



    void Start() {
        myRigidbody = GetComponent<Rigidbody2D>();
        timesThree = false;
    }

void Update(){
     if(timesThree = true){
           Enemy.instance.pointValue *= 3;

       } else{
           Enemy.instance.pointValue *= 1;
       }
}
  void FixedUpdate() {
        change = Vector3.zero;
        change.x = Input.GetAxisRaw("Horizontal"); 
     

    {
        MoveCharacter();
    }
    }
    void MoveCharacter() 
    {
        myRigidbody.MovePosition(transform.position + change.normalized * speed * Time.fixedDeltaTime
        );

         if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)) {
     Check();
    }
    }
    private void Check(){
        if (!_shooterActive){StartCoroutine(Shoot());}
    }

    public IEnumerator Shoot(){ 
        projectile Projectile = Instantiate(this.shooterPreFab, this.transform.position, Quaternion.identity); //instatiate shot
           _shooterActive = true; 
         yield return new WaitForSeconds(delay); 
        _shooterActive = false;
          PlayerShot.Play();
    }
   private void OnTriggerEnter2D (Collider2D other)
    {

        if(other.gameObject.CompareTag("point"))
        {
            Destroy(other.gameObject);} 
            
            if(PowerController.plus2 >= 1){
                PowerController.plus2 -= PowerController.plus2;
                Damage.Play();

             }
        if(other.gameObject.CompareTag("EnemyProjectile"))
        {
            Destroy(other.gameObject);
            GameControl.health -=1; }
           if(PowerController.plus2 >= 1){
                PowerController.plus2 -= PowerController.plus2;
                  Damage.Play();
             }
        if(other.gameObject.CompareTag("powerup")){
            Destroy(other.gameObject);
            PowerController.plus2 +=1;
             StartCoroutine(StartPower());
        }
    }

    IEnumerator StartPower(){
       timesThree = true;
         yield return new WaitForSeconds(10); 
        timesThree = false;

    }
}