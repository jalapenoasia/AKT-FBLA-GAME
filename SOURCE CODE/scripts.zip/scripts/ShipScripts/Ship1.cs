using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ship1 : MonoBehaviour
{
    public projectile shooterPreFab;
    public float speed;
    private Rigidbody2D myRigidbody;
    private Vector3 change;
    public bool _shooterActive;
    private Vector2 velocity;
    private float movementx;
     public float delay;


    void Start() {
        myRigidbody = GetComponent<Rigidbody2D>();
        
    }

  void FixedUpdate() {
        change = Vector3.zero;
        change.x = Input.GetAxisRaw("Horizontal"); 
      if (Input.GetKeyDown(KeyCode.UpArrow)) { Check();
    }

    {
        MoveCharacter();
    }
    }
    void MoveCharacter() 
    {
           if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            movementx = -1;
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            movementx = 1;
        }
         if (Input.GetKeyUp(KeyCode.RightArrow) || Input.GetKeyUp(KeyCode.LeftArrow))
        {
            movementx = 0;
        } 
        myRigidbody.velocity = new Vector2(movementx * speed * Time.fixedDeltaTime, 0);


    }
    private void Check(){
        if (!_shooterActive){StartCoroutine(Shoot());}
    }

    public IEnumerator Shoot(){ 
        projectile Projectile = Instantiate(this.shooterPreFab, this.transform.position, Quaternion.identity); //instatiate shot
           _shooterActive = true; 
         yield return new WaitForSeconds(delay); 
        _shooterActive = false;
        
    }
   
   private void OnTriggerEnter2D (Collider2D other)
    {

        if(other.gameObject.CompareTag("point"))
        {
            Destroy(other.gameObject);} 
           
        if(other.gameObject.CompareTag("EnemyProjectile"))
        {
            Destroy(other.gameObject);
            GameControl.health -=1; }
        
    }
}