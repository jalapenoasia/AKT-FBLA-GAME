using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Timeline : MonoBehaviour
{
    public GameObject sentence;
    public float startdelay;
    public float stopdelay;
    
void Start(){
    StartCoroutine(ShowAndHide());
}

IEnumerator ShowAndHide(){
       sentence.gameObject.SetActive(false);
    yield return new WaitForSeconds(startdelay);
 
    sentence.gameObject.SetActive(true);
    yield return new WaitForSeconds(stopdelay);
    sentence.gameObject.SetActive(false);
}

}